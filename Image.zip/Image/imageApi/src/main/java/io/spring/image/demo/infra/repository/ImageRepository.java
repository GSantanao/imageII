package io.spring.image.demo.infra.repository;

import io.spring.image.demo.domain.entity.Image;
import io.spring.image.demo.domain.enums.ImageExtension;
import io.spring.image.demo.infra.repository.specs.GenericSpecs;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.util.StringUtils;

import java.util.List;

import static io.spring.image.demo.infra.repository.specs.GenericSpecs.*;
import static io.spring.image.demo.infra.repository.specs.ImageSpecs.*;
import static org.springframework.data.jpa.domain.Specification.*;

public interface ImageRepository extends JpaRepository<Image, String>, JpaSpecificationExecutor<Image> {

    /**
     *
     * @param extension
     * @param query
     * @return
     *
     * SELECT * FROM IMAGE WHERE 1 = 1 AND EXTENSION = 'PNG' AND (NAME LIKE 'QUERY' OR TAGS LIKE 'QUERY')
     *
     */

    default List<Image> findByExtensionAndNameOrTagsLike(ImageExtension extension, String query){
     //   Specification <Image> conjunction = (root, q, criteriaBuilder) ->criteriaBuilder.conjunction();
        Specification<Image> spec = where(conjunction());
        if(extension !=null){
            //AND EXTENSION = 'PNG'
//            Specification<Image> extensionEqual = (root, q, cb) -> cb.equal(root.get("extension"), extension);
            spec = spec.and(extensionEqual(extension));
        }
        if(StringUtils.hasText(query)){
            //AND (NAME LIKE 'QUERY' OR TAGS LIKE 'QUERY')
            //Specification<Image> nameLike = (root, q, cb)-> {};
            //Specification<Image> tagsLike = (root, q, cb)-> {};
//            Specification<Image> nameLike = (root, q, cb)-> cb.like(cb.upper(root.get("name")),"%"+query.toUpperCase()+"%");

//            Specification<Image> tagsLike = (root, q, cb)-> cb.like(cb.upper(root.get("tags")),"%"+query.toUpperCase()+"%");

            spec = spec.and(anyOf(nameLike(query), tagsLike(query)));
        }
        return findAll(spec);
    }
}
